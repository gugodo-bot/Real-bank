
let balance = 80650000.00;
let actionCount = 0;

function login() {
    document.getElementById('loginPage').classList.add('hidden');
    document.getElementById('dashboard').classList.remove('hidden');
    loadTransactions();
}

function formatUSD(amount) {
    return "$" + amount.toLocaleString("en-US", {minimumFractionDigits: 2});
}

function withdraw(amount) {
    if (checkLock()) return;
    balance -= amount;
    updateBalance();
    showReceipt("Withdraw", amount);
}

function transfer(amount) {
    if (checkLock()) return;
    const acct = prompt("Enter recipient account number:");
    if (acct) {
        balance -= amount;
        updateBalance();
        showReceipt("Transfer to " + acct, amount);
    }
}

function updateBalance() {
    document.getElementById("balance").innerText = "Account Balance: " + formatUSD(balance);
    actionCount++;
}

function showReceipt(type, amount) {
    document.getElementById("receipt").innerText = `${type} of ${formatUSD(amount)} successful.`;
    if (actionCount >= 3) {
        document.getElementById("locked").innerText = "Account locked. Please visit the nearest Capital One branch for verification.";
    }
}

function checkLock() {
    return actionCount >= 3;
}

function loadTransactions() {
    const transactions = [
        "04/28 - Grocery Store - $234.99",
        "04/29 - Online Purchase - $1,200.00",
        "05/01 - Deposit - $50,000.00"
    ];
    document.getElementById("transactions").innerHTML = "<h3>Recent Transactions:</h3><ul>" +
        transactions.map(t => "<li>" + t + "</li>").join("") + "</ul>";
}
